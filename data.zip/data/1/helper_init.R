mfmm.init = function(y, Z, k,r,x.z=NULL,x.w=NULL,seed=4,scaling=FALSE){
	library("psych") 
	set.seed(seed)

	numobs<-nrow(y)
	p<-ncol(y)
	ybar<- apply(y, 2, mean)
	y<-scale(y, ybar, scale=scaling) 

	# estimate B
	if(!is.null(Z)){
		y_resid = matrix(nrow = nrow(y), ncol = ncol(y))
		B = matrix(nrow = p, ncol = ncol(Z))
		for(j in 1:p){
			y_1 = y[, j]
			# y and Z must be centered!!!!
			fit = lm(y_1~ 0 + Z)
			B[j, ] = summary(fit)$coef[, 1]
			resid_1 = y_1 - Z %*% summary(fit)$coef[, 1]
			y_resid[, j] = resid_1		
		}
	}else{
		B = NULL
		y_resid = y
	}

	x.z<-cbind(rep(1,numobs),x.z)
	q.z<-ncol(x.z) 
	x.w<-cbind(rep(1,numobs),x.w)
	q.w<-ncol(x.w) 
	psi<-0.2*var(y_resid)
	psi<-diag(diag(psi))

	H = fa(y_resid, r, rotate = "none")$loadings
	
	if (k>1) memb<-kmeans(y_resid,k)$cl else memb<-rep(1,numobs)
	for  (i in 1:k) if ((table(memb)[i])<2) memb[sample(1:numobs,2,replace=FALSE)]=i
	phi<-matrix(0,k,q.w)
	w<-table(memb)/sum(table(memb))
	w<-t(t(w))                  
	w<-matrix(w,nrow=k,ncol=numobs)

	### Estimate beta
	if(k == 1){
		Beta<-array(0,c(k,r,q.z)) 
		sigma<-array(0,c(k,r,r))
		sigma[1,,] = diag(r)
	}else{
		Beta<-array(0,c(k,r,q.z))                  
		sigma<-array(0,c(k,r,r))
		la = NULL
		for (i in 1:k) {dati.y<-y_resid[memb==i,]
	            zz<-t(solve(t(H)%*%solve(psi)%*%H)%*%t(H)%*%solve(psi)%*%t(dati.y))
	            dati.x<-x.z[memb==i,]
	            out<-lm(zz~dati.x-1)
	            Beta[i,,]<-t(out$coe)
			la = rbind(la, out$residuals)
		}
		la = matrix(la, ncol = r)
		
		### Estimate the same sigma
		sigma_la = cov(la)
		#sigma_la = t(la) %*% la/(length(la)-1)
		for(i in 1:k){sigma[i,,] = sigma_la}
		for (i in 1:k) {
			Beta[i,,]<-ifelse(is.na(Beta[i,,]),rowMeans(matrix(Beta[i,,],r,q.z),T),matrix(Beta[i,,],r,q.z))
			sigma[i,,]<-ifelse(is.na(sigma[i,,]),rowMeans(sigma[i,,],T),sigma[i,,])
		}
	}
	out<-list(H=H,psi=psi,phi=phi,w=w,Beta=Beta,sigma=sigma, memb = memb, B = B)
	return(out)
}

